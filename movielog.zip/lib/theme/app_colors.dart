import 'package:flutter/material.dart';

abstract final class AppColors {
  static const primary = Color(0xFF6750A4);
  static const background = Color(0xFFFAF9F5);
  static const white = Color(0xFFFFFFFF);
  static const black = Color(0xFF1C1B1F);
  static const gray = Color(0xFF79747E);
}