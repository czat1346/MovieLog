import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'core/validators/member_validators.dart';
import 'data/models/create_member_request.dart';
import 'view_models/sign_up_view_model.dart';
import 'view_models/submit_status.dart';
import 'widgets/movielog_button.dart';

/// 회원가입 화면
///
/// 화면은 의미 단위로 세 개의 Widget으로 나뉩니다.
/// - [_BackHeader]: 뒤로가기 버튼 + 중앙 타이틀
/// - [_SignupForm]: 닉네임 / 이메일 / 비밀번호 입력창
/// - [_TermsAndSubmit]: 약관 동의, 가입 버튼, 로그인 이동 링크
class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final formKey = GlobalKey<FormState>();

  final _nicknameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  final _nicknameFocusNode = FocusNode();
  final _emailFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();

  bool? _nicknameStatus;
  bool? _emailStatus;
  bool? _passwordStatus;
  bool _agreedToTerms = false;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _nicknameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _nicknameFocusNode.dispose();
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  // 가입 가능 조건: 닉네임·이메일은 서버 확인까지 끝나야 한다
  bool _canSubmit(SignUpViewModel vm) =>
      vm.nicknameCheckStatus == CheckStatus.available &&
      vm.emailCheckStatus == CheckStatus.available &&
      _passwordStatus == true &&
      _agreedToTerms &&
      vm.submitStatus != SubmitStatus.submitting; // 제출 중에는 가입 불가(연속 탭 차단)

  // 아이콘: 서버 확인 전에는 체크(✔)를 보여주지 않는다
  bool? _iconStatus(CheckStatus check, bool? formatStatus) {
    if (check == CheckStatus.available) return true;
    if (check == CheckStatus.duplicated) return false;
    if (formatStatus == false) return false; // 형식 오류
    return null;
  }

  void _onNicknameChanged(String value) {
    context.read<SignUpViewModel>().onNicknameChanged(value); // 이전 결과 무효화
    setState(() {
      _nicknameStatus = validateNicknameFormat(value) == null;
    });
  }

  void _onEmailChanged(String value) {
    context.read<SignUpViewModel>().onEmailChanged(value);
    setState(() {
      _emailStatus =
          value.isNotEmpty && value.contains('@') && value.contains('.');
    });
  }

  void _onPasswordChanged(String value) {
    context.read<SignUpViewModel>().onPasswordChanged(); // 서버가 거부한 오류 해제
    setState(() {
      _passwordStatus = validatePasswordFormat(value) == null;
    });
  }

  void _onTogglePasswordVisibility() {
    setState(() {
      _obscurePassword = !_obscurePassword;
    });
  }

  Future<void> _onSignupPressed() async {
    final viewModel = context.read<SignUpViewModel>();
    // 키보드 '완료'로 약관 미동의·중복 확인 미완료·제출 중 상태가 통과되는 것 방지
    if (!_canSubmit(viewModel)) return;
    final isValid = formKey.currentState?.validate() ?? false;
    if (!isValid) return;
    FocusScope.of(context).unfocus();

    await viewModel.submit(
      CreateMemberRequest(
        email: _emailController.text,
        password: _passwordController.text,
        nickname: _nicknameController.text,
      ),
    );
    if (!mounted) return; // 제출 중 화면 이탈 뒤에는 결과를 반영하지 않습니다.

    if (viewModel.submitStatus == SubmitStatus.success &&
        viewModel.createdMemberId != null) {
      // 가입은 토큰을 주지 않으므로 로그인 화면으로 보냅니다. (memberId는 인증 수단이 아님)
      context.go('/login');
      return;
    }
    // 비밀번호 400은 입력칸 errorText로 이미 표시됩니다. 그 외 400·409 등은 Snackbar로 안내합니다.
    final message = viewModel.snackbarMessage;
    if (message != null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SignUpViewModel>();
    // 제출 중에는 뒤로가기·스와이프 백을 막고, 성공/실패로 끝나면 다시 나갈 수 있습니다.
    return PopScope(
      canPop: vm.submitStatus != SubmitStatus.submitting,
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _BackHeader(title: '회원가입'),
                const SizedBox(height: 24),
                const Center(
                  child: Text(
                    '환영합니다!\n간단한 정보만 입력하고 시작해보세요.',
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 32),
                _SignupForm(
                  formKey: formKey,
                  nicknameController: _nicknameController,
                  emailController: _emailController,
                  passwordController: _passwordController,
                  nicknameFocusNode: _nicknameFocusNode,
                  emailFocusNode: _emailFocusNode,
                  passwordFocusNode: _passwordFocusNode,
                  viewModel: vm,
                  nicknameIconStatus: _iconStatus(
                    vm.nicknameCheckStatus,
                    _nicknameStatus,
                  ),
                  emailIconStatus: _iconStatus(
                    vm.emailCheckStatus,
                    _emailStatus,
                  ),
                  passwordStatus: _passwordStatus,
                  obscurePassword: _obscurePassword,
                  onNicknameChanged: _onNicknameChanged,
                  onEmailChanged: _onEmailChanged,
                  onPasswordChanged: _onPasswordChanged,
                  onTogglePasswordVisibility: _onTogglePasswordVisibility,
                  onSignupPressed: _onSignupPressed,
                ),
                const SizedBox(height: 64),
                _TermsAndSubmit(
                  agreedToTerms: _agreedToTerms,
                  onAgreedChanged: (value) {
                    setState(() {
                      _agreedToTerms = value ?? false;
                    });
                  },
                  isFormValid: _canSubmit(vm),
                  onSignupPressed: _onSignupPressed,
                  isSubmitting: vm.submitStatus == SubmitStatus.submitting,
                  onLoginTap: () => context.go('/login'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// 닉네임 / 이메일 / 비밀번호 유효성에 따라 체크(✔) 또는 에러(!) 아이콘을 보여준다.
/// status가 null이면 아직 아무것도 입력하지 않은 상태이므로 아이콘을 표시하지 않는다.
Widget? _statusIcon(bool? status) {
  if (status == null) return null;
  return Padding(
    padding: const EdgeInsets.all(12),
    child: status
        ? SvgPicture.asset(
            'assets/icons/check_circle.svg',
            width: 20,
            height: 20,
          )
        : SvgPicture.asset(
            'assets/icons/error.svg',
            width: 20,
            height: 20,
            colorFilter: const ColorFilter.mode(Colors.red, BlendMode.srcIn),
          ),
  );
}

/// 모든 입력창에 공통으로 적용할 기본 둥근 테두리.
/// 평소(에러 아닐 때)에도 항상 테두리가 보이도록 한다.
const OutlineInputBorder _defaultBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(12)),
  borderSide: BorderSide(color: Color(0xFFD9D9D9), width: 1),
);

const OutlineInputBorder _focusedBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(12)),
  borderSide: BorderSide(color: Color(0xFF7C4DFF), width: 1.5),
);

/// status가 false일 때 테두리와 배경을 빨간색으로 바꿔주는 decoration 조각.
/// 평소에는 둥근 회색 테두리, 포커스 시 보라색 테두리를 적용한다.
InputDecoration _errorStyledDecoration({
  required InputDecoration base,
  required bool? status,
}) {
  final isError = status == false;

  final errorBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: const BorderSide(color: Colors.red, width: 1.5),
  );

  return base.copyWith(
    filled: isError,
    fillColor: isError ? Colors.red.shade50 : null,
    border: _defaultBorder,
    enabledBorder: isError ? errorBorder : _defaultBorder,
    focusedBorder: isError ? errorBorder : _focusedBorder,
    errorBorder: errorBorder,
    focusedErrorBorder: errorBorder,
  );
}

/// 왼쪽 뒤로가기 버튼 + 중앙 타이틀을 같은 y좌표에 배치하는 상단 바.
class _BackHeader extends StatelessWidget {
  const _BackHeader({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              icon: SvgPicture.asset(
                'assets/icons/arrow_back.svg',
                width: 24,
                height: 24,
              ),
              onPressed: () {
                if (context.canPop()) {
                  context.pop();
                } else {
                  context.go('/login');
                }
              },
            ),
          ),
          Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

/// 닉네임 / 이메일 / 비밀번호 입력창.
///
/// 키보드의 '다음' 버튼을 누르면 닉네임 → 이메일 → 비밀번호 순으로 Focus가 이동하고,
/// 비밀번호에서 '완료'를 누르면 가입 버튼과 동일한 검증 로직이 실행된다.
class _SignupForm extends StatelessWidget {
  const _SignupForm({
    required this.formKey,
    required this.nicknameController,
    required this.emailController,
    required this.passwordController,
    required this.nicknameFocusNode,
    required this.emailFocusNode,
    required this.passwordFocusNode,
    required this.viewModel,
    required this.nicknameIconStatus,
    required this.emailIconStatus,
    required this.passwordStatus,
    required this.obscurePassword,
    required this.onNicknameChanged,
    required this.onEmailChanged,
    required this.onPasswordChanged,
    required this.onTogglePasswordVisibility,
    required this.onSignupPressed,
  });

  final GlobalKey<FormState> formKey;

  final TextEditingController nicknameController;
  final TextEditingController emailController;
  final TextEditingController passwordController;

  final FocusNode nicknameFocusNode;
  final FocusNode emailFocusNode;
  final FocusNode passwordFocusNode;

  final SignUpViewModel viewModel;
  final bool? nicknameIconStatus;
  final bool? emailIconStatus;
  final bool? passwordStatus;
  final bool obscurePassword;

  final ValueChanged<String> onNicknameChanged;
  final ValueChanged<String> onEmailChanged;
  final ValueChanged<String> onPasswordChanged;
  final VoidCallback onTogglePasswordVisibility;
  final VoidCallback onSignupPressed;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        children: [
          Row(
            // 에러 문구로 입력창이 커져도 버튼이 가운데로 밀리지 않게 위쪽 정렬
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: nicknameController,
                  focusNode: nicknameFocusNode,
                  onChanged: onNicknameChanged,
                  textInputAction: TextInputAction.next,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  onFieldSubmitted: (_) => emailFocusNode.requestFocus(),
                  decoration: _errorStyledDecoration(
                    base: InputDecoration(
                      labelText: '닉네임',
                      suffixIcon: _statusIcon(nicknameIconStatus),
                      errorText: viewModel.nicknameErrorText, // 서버 결과 연결
                    ),
                    status: nicknameIconStatus,
                  ),
                  validator: validateNicknameFormat,
                ),
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(top: 6), // 56px 입력창 중앙에 44px 버튼
                child: MovieLogButton(
                  label: '중복 확인',
                  isLoading:
                      viewModel.nicknameCheckStatus == CheckStatus.checking,
                  onPressed: viewModel.canCheckNickname
                      ? () => viewModel.checkNickname(nicknameController.text)
                      : null,
                ),
              ),
            ],
          ),
          if (viewModel.nicknameCheckStatus == CheckStatus.available)
            Padding(
              padding: const EdgeInsets.only(left: 12, top: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '사용할 수 있는 닉네임입니다.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ),
          const SizedBox(height: 16),
          Row(
            // 에러 문구로 입력창이 커져도 버튼이 가운데로 밀리지 않게 위쪽 정렬
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: emailController,
                  focusNode: emailFocusNode,
                  onChanged: onEmailChanged,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  onFieldSubmitted: (_) => passwordFocusNode.requestFocus(),
                  decoration: _errorStyledDecoration(
                    base: InputDecoration(
                      labelText: '이메일',
                      suffixIcon: _statusIcon(emailIconStatus),
                      errorText: viewModel.emailErrorText, // 서버 결과 연결
                    ),
                    status: emailIconStatus,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return '이메일을 입력해주세요';
                    }
                    if (!value.contains('@') ||
                        !value.contains('.') ||
                        value.indexOf('@') > value.lastIndexOf('.')) {
                      return '올바른 이메일 형식이 아닙니다';
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(top: 6), // 56px 입력창 중앙에 44px 버튼
                child: MovieLogButton(
                  label: '중복 확인',
                  isLoading: viewModel.emailCheckStatus == CheckStatus.checking,
                  onPressed: viewModel.canCheckEmail
                      ? () => viewModel.checkEmail(emailController.text)
                      : null,
                ),
              ),
            ],
          ),
          if (viewModel.emailCheckStatus == CheckStatus.available)
            Padding(
              padding: const EdgeInsets.only(left: 12, top: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '사용할 수 있는 이메일입니다.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ),
          const SizedBox(height: 16),
          TextFormField(
            controller: passwordController,
            focusNode: passwordFocusNode,
            onChanged: onPasswordChanged,
            obscureText: obscurePassword,
            textInputAction: TextInputAction.done,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            onFieldSubmitted: (_) => onSignupPressed(),
            decoration: _errorStyledDecoration(
              base: InputDecoration(
                labelText: '비밀번호',
                // 로컬 validator를 통과해도 서버가 거부한 값(400)이면 계속 오류로 보입니다.
                errorText: viewModel.passwordErrorText,
                suffixIcon: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_statusIcon(passwordStatus) != null)
                      _statusIcon(passwordStatus)!,
                    IconButton(
                      icon: SvgPicture.asset(
                        obscurePassword
                            ? 'assets/icons/visibility_off.svg'
                            : 'assets/icons/visibility.svg',
                        width: 20,
                        height: 20,
                      ),
                      onPressed: onTogglePasswordVisibility,
                    ),
                  ],
                ),
              ),
              status: viewModel.passwordErrorText != null
                  ? false
                  : passwordStatus,
            ),
            validator: validatePasswordFormat,
          ),
        ],
      ),
    );
  }
}

/// 필수 약관 동의 체크박스, 가입 버튼, 로그인 이동 링크.
class _TermsAndSubmit extends StatelessWidget {
  const _TermsAndSubmit({
    required this.agreedToTerms,
    required this.onAgreedChanged,
    required this.isFormValid,
    required this.isSubmitting,
    required this.onSignupPressed,
    required this.onLoginTap,
  });

  final bool agreedToTerms;
  final ValueChanged<bool?> onAgreedChanged;
  final bool isFormValid;
  final bool isSubmitting;
  final VoidCallback onSignupPressed;
  final VoidCallback onLoginTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Checkbox(value: agreedToTerms, onChanged: onAgreedChanged),
            const Text('필수 약관에 동의합니다'),
          ],
        ),
        const SizedBox(height: 8),
        MovieLogButton(
          label: '가입하기',
          width: double.infinity,
          isLoading: isSubmitting,
          onPressed: isFormValid ? onSignupPressed : null,
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('이미 계정이 있나요? '),
            GestureDetector(
              onTap: onLoginTap,
              child: const Text(
                '로그인',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
